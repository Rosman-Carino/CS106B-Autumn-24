/*
 * File: main.cpp
 * --------------
 * Blank C++ project configured to use Stanford cslib and Qt
 */

#include "console.h"
#include "simpio.h"
#include "vector.h"
#include "error.h"
#include "SimpleTest.h" // IWYU pragma: keep (needed to quiet spurious warning)
using namespace std;


int main()
{
    if (runSimpleTests(SELECTED_TESTS)) {
        return 0;
    }

    string name = getLine("What is your name?");
    cout << "Hello, " << name << endl;
    return 0;
}
/**
 * @brief Goal: Given an integer `n` return the sum of the digits. Look at the
 *          provided test cases all the way at the bottom.
 * @param n
 * @return
 */
int digitSum(int n) {
    // TODO
    return 0;
}

/**
 * @brief Goal: Given an integer, print all base 10 numbers that have exactly that
 *              many `digits`
 * E.X. digits = 2. We should print out the following:
 * 00
 * 01
 * 02
 * 03
 * ..
 * 96
 * 97
 * 98
 * 99
 * @param digits
 */
void printNumbers(int digits) {
    // TODO
}



/**
 * @brief Goal: Given an integer `digits`, print all binary numbers that have exactly
 *          that many `digits`
 * E.X. digits = 2. We should print out the following:
 * 00
 * 01
 * 10
 * 11
 * E.X. digits = 3. We should print out the following:
 * 000
 * 001
 * 010
 * 011
 * 100
 * 101
 * 110
 * 111
 * @param digits
 */
void printAllBinary(int digits) {
    // TODO
}


PROVIDED_TEST("Digit Sum ") {
    EXPECT_EQUAL(digitSum(1725), 15);
    EXPECT_EQUAL(digitSum(123456), 21);
    EXPECT_EQUAL(digitSum(2300005), 10);
    EXPECT_EQUAL(digitSum(-1729), -19);
    EXPECT_EQUAL(digitSum(-7), -7);
    EXPECT_EQUAL(digitSum(5), 5);
    EXPECT_EQUAL(digitSum(0), 0);

}


